#include "params.h"

void update(const float temp, int grid[L][L]);

double calculate(int grid[L][L], int *M_max);
