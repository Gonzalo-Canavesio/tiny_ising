#include <stdint.h>


double optimized_random_probability(void);

void seed(uint64_t seed);
