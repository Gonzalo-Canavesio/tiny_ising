#include "params.h"

void update(const float temp, int grid[L][L]);

float calculate(const int grid[L][L], int *M_max);
