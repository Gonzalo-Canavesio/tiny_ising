#include <stdint.h>


float optimized_random_probability(void);

void seed(uint64_t seed);
