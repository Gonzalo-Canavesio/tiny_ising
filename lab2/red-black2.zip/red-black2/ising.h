#include "params.h"

void update(const float temp, int (*red_grid)[L], int (*black_grid)[L]);
float calculate(int (*red_grid)[L], int (*black_grid)[L], int *M_max);
